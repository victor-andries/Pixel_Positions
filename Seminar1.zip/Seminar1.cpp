#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <openssl/rsa.h>
#include <openssl/aes.h>
#include <openssl/pem.h>
#include <openssl/sha.h>
#include <openssl/applink.c>
#include <stdlib.h>
#include <string.h>


int main()
{
	FILE* file = fopen("RSAKey.pem", "rb");
	RSA* key = PEM_read_RSAPublicKey(file, NULL, NULL, NULL);
	FILE* fsig = fopen("signature.sig", "rb");
	fseek(fsig, 0, SEEK_END);
	int fsigSize = ftell(fsig);
	rewind(fsig);
	unsigned char* sig = (unsigned char*)malloc(fsigSize);
	fread(sig, 1, fsigSize, fsig);
	unsigned char* sha256 = (unsigned char*)malloc(SHA256_DIGEST_LENGTH);
	RSA_public_decrypt(sizeof(key), sig, sha256, key, RSA_PKCS1_PADDING);

	fclose(file);
	fclose(fsig);

	for (unsigned char i = 0; i < SHA256_DIGEST_LENGTH; i++) {
		printf("%02X ", sha256[i]);
	}
	printf("\n\n");

	//FILE* fwordlist = fopen("wordlist.txt", "rb");
	//int wordcount = 0;
	//char buffer[2048];
	//while ((fgets(buffer, 2048, fwordlist))) {
	//	wordcount++;
	//	char* line = buffer;
	//	memcpy(line, buffer, strlen(buffer));
	//	line[strcspn(line, "\r\n")] = 0; // Remove newline character

	//	char salt[] = "ISMsalt";
	//	char* lineSalt = strcat(line, salt);
	//	int hashSize = strlen(lineSalt);
	//	SHA256_CTX ctx;
	//	SHA256_Init(&ctx);
	//	unsigned char* hashWord = (unsigned char*)malloc(SHA256_DIGEST_LENGTH);
	//	SHA256_Update(&ctx, lineSalt, hashSize);
	//	SHA256_Final(hashWord, &ctx);

	//	unsigned char* foundWord = (unsigned char*)malloc(strlen(line - 7));
	//	if (memcmp(hashWord, sha256, SHA256_DIGEST_LENGTH) == 0) {
	//		printf("\n");
	//		memcpy(foundWord, line, strlen(line - 7));
	//		for (int i = 0; i < strlen(line) - 7; i++) {
	//			printf("%c", line[i]);
	//		}
	//		printf(" %d", wordcount);
	//	}
	//	if (wordcount <= 5) {
	//		printf("Line %d: '%s' + salt = '%s'\n", wordcount, buffer, lineSalt);
	//	}

	//	//printf("Line %d: %s\n", wordcount, line);
	//}

	//fclose(fwordlist);

	//FILE* file1 = fopen("wordlist.txt", "rb");
	//char buffer[200];
	//int wordcount = 0;
	//while (fgets(buffer, sizeof(buffer), file1)) {
	//	wordcount++;
	//	char* line = buffer;
	//	memcpy(line, buffer, strlen(buffer));
	//	buffer[strcspn(buffer, "\r\n")] = 0;
	//	char salt[] = "ISMSalt";
	//	strcat(line, salt);
	//	unsigned char* foundWord = (unsigned char*)malloc(strlen(line - 7));
	//	if (!memcmp("passwordISMSalt", line, strlen(line))) {
	//		memcpy(foundWord, line, strlen(line - 7));
	//		for (int i = 0; i < strlen(line) - 7; i++) {
	//			printf("%c", line[i]);
	//		}
	//		printf("\n%d", wordcount);
	//	}
	//	
	//	//printf("%s\n", line);
	//}

	//fclose(file1);

	FILE* f = fopen("students.txt", "r");
	/*fseek(f, 0, SEEK_END);
	int fileSize = ftell(f);
	fseek(f, 0, SEEK_SET);

	char* content = (char*)malloc(fileSize + 1);
	fread(content, 1, fileSize, f);
	content[fileSize] = '\0';
	char* token = strtok(content, ";");
	while (token != NULL) {
		printf("%s", token);
		token = strtok(NULL, ";");
	}
	fclose(f);
	free(content);*/

	char line[1000];
	while (fgets(line, sizeof(line), f)) {
		line[strcspn(line, "\n")] = 0;
		char* lineCopy = (char*)malloc(strlen(line) + 1);
		strcpy(lineCopy, line);
		char* token = strtok(lineCopy, ";");
		int currentColumn = 0;
		while (token != NULL && currentColumn < 1) {
			token = strtok(NULL, ";");
			currentColumn++;
		}
		if (token != NULL) {
			printf("%s\n", token);
		}
	}

}