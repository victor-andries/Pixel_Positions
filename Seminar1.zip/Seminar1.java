import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    public static void readTextFileString() {
        try {
            String content = Files.readString(Paths.get("example.txt"));
            System.out.println("File content:\n" + content);
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    public static void generateFilesDigest(String folderPath) throws NoSuchAlgorithmException, IOException {
        File folder = new File(folderPath);
        File[] files = folder.listFiles();
        MessageDigest md5 = MessageDigest.getInstance("MD5");

        for (File file : files) {
            byte[] content = Files.readAllBytes(file.toPath());
            byte[] digest = md5.digest(content);

            StringBuilder hexString = new StringBuilder();
            for (int i=0;i<digest.length;i++) {
                hexString.append(String.format("%02X", digest[i]));
            }
            String digestFilename = file.getName().replace(".txt",".digest");
            File fileout = new File(digestFilename);
            BufferedWriter buf = new BufferedWriter(new FileWriter("digests\\" + fileout));
            buf.write(hexString.toString());
            buf.close();
        }
    }

    public static void generateHMACFiles(String folderPath, String sharedSecret) throws NoSuchAlgorithmException, InvalidKeyException, IOException {
        File folder = new File(folderPath);
        File[] files = folder.listFiles();
        for (File file : files) {
            Mac mac = Mac.getInstance("HmacSHA1");
            SecretKeySpec spec = new SecretKeySpec(sharedSecret.getBytes(), "HmacSHA1");
            mac.init(spec);
            byte[] macHex = mac.doFinal(Files.readAllBytes(file.toPath()));
            String fileName = file.getName().replace(".txt",".hmac");
            String base64File = Base64.getEncoder().encodeToString(macHex);
            BufferedWriter buf = new BufferedWriter(new FileWriter("hmacs\\" + fileName));
            buf.write(base64File);
            buf.close();

        }
    }

    public static boolean retrieveAndVerifyDocument(String file, String hashFile, String hmacFile, String secretKey) throws Exception {

        File f = new File(file);
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        byte[] data = Files.readAllBytes(f.toPath());
        byte[] hash = md5.digest(data);
        StringBuilder hexString = new StringBuilder();
        for (int i=0;i<hash.length;i++) {
            hexString.append(String.format("%02X", hash[i]));
        }
        String storedHash = hexString.toString();

        File hashfile = new File(hashFile);
        byte[] dataHash = Files.readAllBytes(hashfile.toPath());
        String Hashdata = new String(dataHash);

        boolean goodHash = storedHash.equals(Hashdata);

        Mac mac = Mac.getInstance("HmacSHA1");
        SecretKeySpec spec = new SecretKeySpec(secretKey.getBytes(), "HmacSHA1");
        mac.init(spec);

        byte[] macHash = mac.doFinal(data);
        String macBase64 = Base64.getEncoder().encodeToString(macHash);

        File hmacfile = new File(hmacFile);
        byte[] hmacbytes = Files.readAllBytes(hmacfile.toPath());
        String macfile64 = new String(hmacbytes);
        boolean goodHmac = macBase64.equals(macfile64);

        if (goodHash && goodHmac) {
            return true;
        }
        return false;
    }

    public static byte[] generateSecretKey(String sharedSecret) throws Exception {
        byte[] bytes = sharedSecret.getBytes();
        byte mask = (byte)2;
        bytes[14] = (byte)(bytes[14]^mask);
        return bytes;
    }

    public static void encryptDocument(String filePath, byte[] key) throws Exception {
        File file = new File(filePath);
        byte[] data = Files.readAllBytes(file.toPath());
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        SecretKeySpec spec = new SecretKeySpec(key, "AES");
        cipher.init(Cipher.ENCRYPT_MODE, spec);
        byte[] enc = cipher.doFinal(data);
        String fileName = file.getName().replace(".txt", ".enc");
        BufferedOutputStream bf= new BufferedOutputStream(new FileOutputStream(fileName));
        bf.write(enc);
        bf.close();
    }

    public static void readAndSplit(String filename, String separator) {
        try {
            String content = Files.readString(Paths.get(filename));
            String[] lines = content.split(separator);

            for (int i = 0; i < lines.length; i++) {
                String line = lines[i].trim();
                if (!line.isEmpty()) {
                    System.out.println("Line " + (i + 1) + ": " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    public static void printColumn(String filename, String separator, int columnIndex) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            int lineNumber = 1;

            System.out.println("Column " + columnIndex + " from " + filename + ":");
            System.out.println("------------------------");

            while ((line = reader.readLine()) != null) {
                String[] columns = line.split(separator);

                if (columnIndex < columns.length) {
                    System.out.println("Line " + lineNumber + ": " + columns[columnIndex].trim());
                } else {
                    System.out.println("Line " + lineNumber + ": Column not found");
                }
                lineNumber++;
            }

        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws Exception {
        generateFilesDigest("messages");

        generateHMACFiles("messages", "sqdy0m-l!t%h1234");

        System.out.println(retrieveAndVerifyDocument("messages\\message_10_5emaqc.txt", "digests\\message_10_5emaqc.digest", "hmacs\\message_10_5emaqc.hmac", "sqdy0m-l!t%h1234"));

        byte[] derivedKey = generateSecretKey("sqdy0m-l!t%h1234");

        encryptDocument("messages\\message_10_5emaqc.txt", derivedKey);

        BufferedReader buf = new BufferedReader(new FileReader("messages\\message_10_5emaqc.txt"));
        String word;
        boolean found = false;
        int lineNumber=0;
        while ((word = buf.readLine()) != null) {
            lineNumber++;
            String anotherWord = word.trim() + "ism";
            System.out.println(anotherWord);
            if(anotherWord.equals("sadism")) {
                found = true;
                System.out.println();
                System.out.println(anotherWord);
                System.out.println(lineNumber);
            }
        }
    }
}